
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'arnold2me',
  applicationName: 'my-first-app',
  appUid: 'HyfZL70xS27NppNw6v',
  orgUid: 'n1jJbgN8Js8G05nHMZ',
  deploymentUid: '9521bc98-ff7e-4b72-8ea1-59ce246adfb5',
  serviceName: 'wils-response-bot',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.17',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'wils-response-bot-dev-router', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.probot, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}