
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'arnold2me',
  applicationName: 'my-first-app',
  appUid: 'HyfZL70xS27NppNw6v',
  orgUid: 'n1jJbgN8Js8G05nHMZ',
  deploymentUid: '1a0e9aef-15e7-4025-b448-6e7eb288d5af',
  serviceName: 'sls-response-bot',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.15',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'sls-response-bot-dev-router', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.probot, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}